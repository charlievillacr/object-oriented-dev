class Car:
    id = int
    license = str
    driver = str
    passegenger = int