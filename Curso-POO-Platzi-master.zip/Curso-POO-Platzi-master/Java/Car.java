class Car {
    Integer id;
    String license;
    String driver;
    Integer passegenger;
}