class Payment {
    Integer id;
}