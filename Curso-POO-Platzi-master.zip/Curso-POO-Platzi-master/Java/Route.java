import java.util.ArrayList;

class Route {
    Integer id;
    ArrayList<Double> start;
    ArrayList<Double> end;
}