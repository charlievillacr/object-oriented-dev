class Account {
    Integer id;
    String name;
    String document;
    String email;
    String password;
}